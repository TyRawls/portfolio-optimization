"""
File: lambda_function.py (cloud deployment)
Author: Ty Rawls
Date: 2024-03-07
Description: When new stock data arrives in the AWS S3 bucket, it triggers AWS Lambda to send 
the data to AWS RDS (PostgreSQL).
"""

import io
import os
import csv
import boto3
import psycopg2

# Initialize the S3 client
s3 = boto3.client('s3')

def lambda_handler(event, context):
    print(f'Printing event info: {event}')
    
    # Retrieve S3 bucket and key from event
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    
    # Display bucket name and key from event
    print(f'S3 Bucket Name: {bucket}')
    print(f'S3 Key (Filename): {key}')

    # Connect to AWS RDS - PostgreSQL instance
    conn = psycopg2.connect(
        dbname   = os.environ.get('DBNAME'),
        user     = os.environ.get('USER'),
        password = os.environ.get('PASS'),
        host     = os.environ.get('HOST'),
        port     = os.environ.get('PORT'),  # Default PostgreSQL port
        connect_timeout = 30                # Set timeout to 30 seconds
    )
    # Create a cursor object to execute queries
    cursor = conn.cursor()
    
    # Download file from S3
    response = s3.get_object(Bucket=bucket, Key=key)
    data = response['Body'].read().decode('utf-8')
    csv_reader = csv.reader(io.StringIO(data))
    next(csv_reader) # Skip the header row
    
    # If new data has been pushed to the 'stock-info' folder in the S3 bucket, 
    # then insert data into the 'company_info' table in the database
    if 'stock-info' in key:
        for row in csv_reader:
            # Construct the SQL INSERT statement for the 'company_info' table
            insert_query = 'INSERT INTO company_info (ticker, company_name, exchange, ceo, sector, industry, market_cap) VALUES (%s, %s, %s, %s, %s, %s, %s)'
            
            # Execute the INSERT statement with the current row data
            cursor.execute(insert_query, row)
    else:
        print('This event does not contain data for the company_info table.')
            
      
    # If new data has been pushed to the 'stock-price' folder in the S3 bucket,     
    # then insert data into the 'daily_stock_price' table in the database
    if 'stock-price' in key:
        for row in csv_reader:
            # Construct the SQL INSERT statement for the 'daily_stock_info' table
            insert_query = 'INSERT INTO daily_stock_data (date, ticker, open, high, low, close, volume) VALUES (%s, %s, %s, %s, %s, %s, %s)'
            
            # Execute the INSERT statement with the current row data
            cursor.execute(insert_query, row)
    else:
        print('This event does not contain data for the daily_stock_data table.')

           
    # Commit the transaction
    conn.commit()
    
    # Close the cursor and connection
    cursor.close()
    conn.close()
    
    
event={'Records': [{'eventVersion': '2.1', 'eventSource': 'aws:s3', 'awsRegion': 'ca-central-1', 'eventTime': '2024-03-06T01:54:41.738Z', 'eventName': 'ObjectCreated:Put', 'userIdentity': {'principalId': 'AWS:AIDA2D6IAI5SNKIAESCT6'}, 'requestParameters': {'sourceIPAddress': '73.139.20.191'}, 'responseElements': {'x-amz-request-id': 'H7P81BBYM46C8FN7', 'x-amz-id-2': 'ARDJ+Y62GWqy648wU5WjGX+VNbOhczevZLJMXOqOPGjVeTO4MMUIy9s+Sy9unebrlG+ARp2N4C5UF1EGQi2/rBoHHv7AQpEr'}, 's3': {'s3SchemaVersion': '1.0', 'configurationId': '9d0ea791-4e02-496a-8715-4d5b86365f0b', 'bucket': {'name': 'api-team-bucket-1', 'ownerIdentity': {'principalId': 'AL4ZX5O70OWXJ'}, 'arn': 'arn:aws:s3:::api-team-bucket-1'}, 'object': {'key': 'stock-info/api_20240305_td_info_0.csv', 'size': 168, 'eTag': '413e02c68fabfacb45cad58f95ad714d', 'versionId': 'msEAL9_H8RB96GFN4CZ.HpWazL5Jj0GI', 'sequencer': '0065E7CCE1A3CCBA08'}}}]}
event={'Records': [{'eventVersion': '2.1', 'eventSource': 'aws:s3', 'awsRegion': 'ca-central-1', 'eventTime': '2024-03-06T01:54:43.575Z', 'eventName': 'ObjectCreated:Put', 'userIdentity': {'principalId': 'AWS:AIDA2D6IAI5SNKIAESCT6'}, 'requestParameters': {'sourceIPAddress': '73.139.20.191'}, 'responseElements': {'x-amz-request-id': 'CKKPPGDHQMCGGP0Z', 'x-amz-id-2': '9RBA4EaTk6LW5I2+EO+LbeJF2iMXRrWSlhG3cDXPMIlnmlhurOojDiIsRtdpNd/+m7XrW13I6F1jJ3+MmXdN1GRAc4uMzgUU'}, 's3': {'s3SchemaVersion': '1.0', 'configurationId': '9d0ea791-4e02-496a-8715-4d5b86365f0b', 'bucket': {'name': 'api-team-bucket-1', 'ownerIdentity': {'principalId': 'AL4ZX5O70OWXJ'}, 'arn': 'arn:aws:s3:::api-team-bucket-1'}, 'object': {'key': 'stock-price/api_20240305_td_price_0.csv', 'size': 114158, 'eTag': '5b766df0fb435051d4a6c2cdf231382c', 'versionId': 'RryaU.234S_7YjbiD.1sXYlrwt3t1x.Y', 'sequencer': '0065E7CCE2EE800D56'}}}]}